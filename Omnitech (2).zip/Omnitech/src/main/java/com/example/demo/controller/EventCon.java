package com.example.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import com.example.demo.entities.Event;
import com.example.demo.entities.Photo;
import com.example.demo.service.EventService;
import com.example.demo.service.PhotoServices;



@Controller
public class EventCon {
	@Autowired
	EventService evs;
	@Autowired
	PhotoServices ps;
	@GetMapping("map-event")
	public String createEvent(Model model) {
		//fetching the songs by using song service
		List<Photo> photoslist=ps.viewPhotos();
		model.addAttribute("photoslist",photoslist);
		return "createEvent";
	}
	@PostMapping("add-Event")
	public String addPhotos(@ModelAttribute Event event) {
		
		evs.addEvent(event);
		 List<Photo>photoslist=event.getPhotoslist();
	     for(Photo photo:photoslist) {
		 photo.getEvent().add(event);
		 ps.updatePhoto(photo);
		 }
		
		return "Eventsuccess";
		 
		
	}
	@GetMapping("view-event")
	public String viewEvent(Model model) {
		
		List<Event>event=evs.fetchEvent();
		model.addAttribute("event",event);
	
		return "viewEvent";
		
		
	}
	/*@PostMapping("add-Event")
	public String addPhotos(@ModelAttribute Event event, @RequestParam("photos") MultipartFile[] photos) {
	    // Process event details
		es.addEvent(event);
		 List<Photo>photoslist=event.getPhotoslist();
	    for (MultipartFile photo : photos)
	    {
	      
	   	 ((Photo) photo).getEvent().add(event);
		 ps.updatePhoto(photo);
	    }
	    
	    // Save event details to database
	    
	    return "Eventsuccess";
	}*/


}







